package Controller;

import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;

public class FXMLpoinforuserController {

    private Parent root;
    private Scene scene;
    private Stage stage;


    
    private int poinValue = 500;

    @FXML
    private Button Home2;

    @FXML
    private Button Catalog2;

    @FXML
    private Button Article2;

    @FXML
    private Button Order2;

    @FXML
    private Button logout2;

    @FXML
    private Button profile2;

    @FXML
    private Button tukar;

    @FXML
    private Button Checkout;

    @FXML
    private TextField masukanpoin;

    @FXML
    private Label ecobrickdidapat;

    @FXML
    private Label poin;

    @FXML
    void Article(ActionEvent event) throws IOException{
      root  = FXMLLoader.load(getClass().getResource("/FXML/FXMLpilihanArtikel.fxml"));
      stage = (Stage)((Node)event.getSource()).getScene().getWindow();
      scene = new Scene(root);
      stage.setScene(scene);
      stage.show();
    }

    @FXML
    void Catalog(ActionEvent event) throws IOException{
        root  = FXMLLoader.load(getClass().getResource("/FXML/katalog.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
      scene = new Scene(root);
      stage.setScene(scene);
      stage.show();
    }

    @FXML
    void Home(ActionEvent event) throws IOException {
      root  = FXMLLoader.load(getClass().getResource("/FXML/FXMLhome.fxml"));
      stage = (Stage)((Node)event.getSource()).getScene().getWindow();
      scene = new Scene(root);
      stage.setScene(scene);
      stage.show();
    }

    @FXML
    void Order(ActionEvent event) throws IOException {
      root  = FXMLLoader.load(getClass().getResource("/FXML/order.fxml"));
      stage = (Stage)((Node)event.getSource()).getScene().getWindow();
      scene = new Scene(root);
      stage.setScene(scene);
      stage.show();
    }


    @FXML
    void Profile(ActionEvent event) throws IOException  {
      root  = FXMLLoader.load(getClass().getResource("/FXML/FXMLprofile.fxml"));
      stage = (Stage)((Node)event.getSource()).getScene().getWindow();
      scene = new Scene(root);
      stage.setScene(scene);
      stage.show();
    }

    @FXML
    void LogOut(ActionEvent event) throws IOException  {
      root  = FXMLLoader.load(getClass().getResource("/FXML/FXMLpembuka.fxml"));
      stage = (Stage)((Node)event.getSource()).getScene().getWindow();
      scene = new Scene(root);
      stage.setScene(scene);
      stage.show();
    }

    @FXML
    public void initialize() {
        poin.setText(String.valueOf(poinValue));
    }

    @FXML
    void tukarButtonClicked() {
    String inputPoin = masukanpoin.getText();
    if (inputPoin.isEmpty()) {
        showErrorMessage("Masukkan nilai poin yang akan ditukar!");
        return;
    }

    int poinToExchange;
    try {
        poinToExchange = Integer.parseInt(inputPoin);
    } catch (NumberFormatException e) {
        showErrorMessage("Nilai poin tidak valid!");
        return;
    }

    if (poinToExchange % 100 != 0) {
        showErrorMessage("Penukaran poin harus kelipatan 100!");
        return;
    }

    int ecobrickReceived = poinToExchange / 4;
    ecobrickdidapat.setText(String.valueOf(ecobrickReceived));
}

    @FXML
    void checkoutButtonClicked() {
        String inputPoin = masukanpoin.getText();
        if (inputPoin.isEmpty()) {
            showErrorMessage("Masukkan nilai poin yang akan ditukar!");
            return;
        }

        int poinToExchange;
        try {
            poinToExchange = Integer.parseInt(inputPoin);
        } catch (NumberFormatException e) {
            showErrorMessage("Nilai poin tidak valid!");
            return;
        }

        if (poinToExchange % 100 != 0) {
            showErrorMessage("Penukaran poin harus kelipatan 100!");
            return;
        }

        if (poinToExchange > poinValue) {
            showErrorMessage("Poin tidak mencukupi!");
            return;
        }

        poinValue -= poinToExchange;
        poin.setText(String.valueOf(poinValue));
        masukanpoin.clear();
        ecobrickdidapat.setText("");
    }

    private void showErrorMessage(String message) {
        Alert alert = new Alert(AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
