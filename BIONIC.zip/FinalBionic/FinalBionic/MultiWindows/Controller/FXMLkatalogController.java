package Controller;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.beans.binding.IntegerExpression;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.io.xml.StaxDriver;
import com.thoughtworks.xstream.security.AnyTypePermission;

import Model.Pembelian;

public class FXMLkatalogController implements Initializable {

    private Parent root;
    private Scene scene;
    private Stage stage;
    private boolean isDataSaved = false;

    @FXML
    private Button Article2;

    @FXML
    private Button Catalog2;

    @FXML
    private Button Home2;

    @FXML
    private Button Order2;

    @FXML
    private Button Poin2;

    @FXML
    private Button logout2;

    @FXML
    private Button profile2;

    @FXML
    private Button profile21;

    @FXML
    private Button saveBig;

    @FXML
    private Button saveMedium;

    @FXML
    private Button saveSmall;

    @FXML
    private TextField total;

    @FXML
    private TextField poin;

    @FXML
    private ChoiceBox<String> ChoiceBig;

    @FXML
    private ChoiceBox<String> ChoiceMedium;

    @FXML
    private ChoiceBox<String> ChoiceSmall;

    @FXML
    private TextField tf1;

    @FXML
    private TextField tf2;

    @FXML
    private TextField tf3;

    @FXML
    private IntegerExpression newValue;

    private boolean isDataValid = false;

    private List<Pembelian> pembelianList = new ArrayList<>();


    @FXML
    void Article2(ActionEvent event) throws IOException {
        root = FXMLLoader.load(getClass().getResource("/FXML/FXMLpilihanArtikel.fxml"));
        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    void Catalog2(ActionEvent event) {

    }

    @FXML
    void Home2(ActionEvent event) throws IOException {
        root = FXMLLoader.load(getClass().getResource("/FXML/FXMLhome.fxml"));
        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    void Order2(ActionEvent event) throws IOException {
        root = FXMLLoader.load(getClass().getResource("/FXML/order.fxml"));
        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    void Poin2(ActionEvent event) throws IOException {
        root = FXMLLoader.load(getClass().getResource("/FXML/FXMLpoinforuser.fxml"));
        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    void logout2(ActionEvent event) throws IOException {
        root = FXMLLoader.load(getClass().getResource("/FXML/FXMLpembuka.fxml"));
        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    void profile2(ActionEvent event) throws IOException {
        root = FXMLLoader.load(getClass().getResource("/FXML/FXMLprofile.fxml"));
        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    void tf1(ActionEvent event) {

    }

    @FXML
    void tf2(ActionEvent event) {

    }

    @FXML
    void tf3(ActionEvent event) {

    }

    @FXML
    void ChoiceBig(ActionEvent event) {

    }

    @FXML
    void ChoiceMedium(ActionEvent event) {

    }

    @FXML
    void ChoiceSmall(ActionEvent event) {

    }

    private ObservableList<Pembelian> readPembelianFromXML(String filePath) {
    List<Pembelian> pembelianList = new ArrayList<>();

    try {
        FileInputStream fileInputStream = new FileInputStream(filePath);
        XStream xstream = new XStream(new StaxDriver());
        xstream.alias("list", List.class);
        xstream.alias("Pembelian", Pembelian.class);
        xstream.addPermission(AnyTypePermission.ANY);
        pembelianList = (List<Pembelian>) xstream.fromXML(fileInputStream);
        fileInputStream.close();
    } catch (FileNotFoundException e) {
        e.printStackTrace();
    } catch (IOException e) {
        e.printStackTrace();
    }

    // Mengonversi List menjadi ObservableList
    ObservableList<Pembelian> observablePembelianList = FXCollections.observableArrayList(pembelianList);

    return observablePembelianList;
}



private void saveDataToXML() {
    String filePath = "DataPembelian.xml";

    try {
        FileOutputStream fileOutputStream = new FileOutputStream(filePath);
        XStream xstream = new XStream(new StaxDriver());
        xstream.alias("list", List.class);
        xstream.alias("Pembelian", Pembelian.class);
        xstream.addPermission(AnyTypePermission.ANY);
        xstream.toXML(pembelianList, fileOutputStream);
        fileOutputStream.close();
    } catch (IOException e) {
        e.printStackTrace();
    }
}

    
    
    
    
@FXML
private void profile21(ActionEvent event) throws IOException {
    if (!isDataSaved) {
        showDataWarning();
        return;
    }

    saveDataToXML();

    root = FXMLLoader.load(getClass().getResource("/FXML/metode.fxml"));
    stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
    scene = new Scene(root);
    stage.setScene(scene);
    stage.show();
}


    @FXML
    private void saveBig(ActionEvent event) {
        String selectedBig = ChoiceBig.getValue();
        int quantity = Integer.parseInt(tf1.getText());

        if (quantity % 25 != 0) {
            // Jumlah harus kelipatan 25
            showAlert("Invalid Quantity", "Quantity must be a multiple of 25.");
            return;
        }

        int totalPrice = quantity * 25000;
        total.setText(String.valueOf(totalPrice));

        if (quantity >= 100) {
            int point = quantity / 10;
            poin.setText(String.valueOf(point));
        } else {
            int point = 0;
            poin.setText(String.valueOf(point));
        }
        isDataSaved = true;

        pembelianList.add(new Pembelian(selectedBig, quantity, totalPrice, Integer.parseInt(poin.getText()), "Big"));

     
    }
    @FXML
    void saveMedium(ActionEvent event) {
        String selectedMedium = ChoiceMedium.getValue();
        int quantity = Integer.parseInt(tf2.getText());

        if (quantity % 25 != 0) {
            // Jumlah harus kelipatan 25
            showAlert("Invalid Quantity", "Quantity must be a multiple of 25.");
            return;
        }

        int totalPrice = quantity * 15000;
        total.setText(String.valueOf(totalPrice));

        if (quantity >= 100) {
            int point = quantity / 10;
            poin.setText(String.valueOf(point));
        } else {
            int point = 0;
            poin.setText(String.valueOf(point));
        }
        isDataSaved = true;

        pembelianList.add(new Pembelian(selectedMedium, quantity, totalPrice, Integer.parseInt(poin.getText()), "Medium"));

     
    }

    @FXML
    void saveSmall(ActionEvent event) {
        String selectedSmall = ChoiceSmall.getValue();
        int quantity = Integer.parseInt(tf3.getText());

        if (quantity % 25 != 0) {
            // Jumlah harus kelipatan 25
            showAlert("Invalid Quantity", "Quantity must be a multiple of 25.");
            return;
        }

        int totalPrice = quantity * 10000;
        total.setText(String.valueOf(totalPrice));
        
        if (quantity >= 100) {
            int point = quantity / 10;
            poin.setText(String.valueOf(point));
        } else {
            int point = 0;
            poin.setText(String.valueOf(point));
        }
        isDataSaved = true;

        pembelianList.add(new Pembelian(selectedSmall, quantity, totalPrice, Integer.parseInt(poin.getText()), "Small"));

       
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        ChoiceBig.getItems().addAll("Aqua", "Fanta", "Teh Pucuk");
        ChoiceMedium.getItems().addAll("Aqua", "Fanta", "Teh Pucuk");
        ChoiceSmall.getItems().addAll("Aqua", "Fanta", "Teh Pucuk");

        ChoiceSmall.getSelectionModel().selectedIndexProperty().addListener((observable, oldValue, newValue) -> {
            if (newValue.intValue() >= 0) {
                String selectedSmall = ChoiceSmall.getItems().get(newValue.intValue());
            }
        });

        ChoiceBig.getSelectionModel().selectedIndexProperty().addListener((observable, oldValue, newValue) -> {
            if (newValue.intValue() >= 0) {
                String selectedBig = ChoiceBig.getItems().get(newValue.intValue());
            }
        });

        ChoiceSmall.getSelectionModel().selectedIndexProperty().addListener((observable, oldValue, newValue) -> {
            if (newValue.intValue() >= 0) {
                String selectedMedium = ChoiceSmall.getItems().get(newValue.intValue());
            }
        });

      
    }
    private void showDataWarning() {
     Alert alert = new Alert(AlertType.WARNING);
     alert.setTitle("Peringatan");
     alert.setHeaderText(null);
     alert.setContentText("Silakan masukkan data pembelian terlebih dahulu!");
     alert.showAndWait();
 }   

 private void showAlert(String title, String message) {
    Alert alert = new Alert(AlertType.WARNING);
    alert.setTitle(title);
    alert.setHeaderText(null);
    alert.setContentText(message);
    alert.showAndWait();
}


 
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
