/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.beans.binding.IntegerExpression;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;

/**
 *
 * @author Arga
 */

// deklarasi untuk objek di fxml


import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class FXMLcatalogPengelolaController implements Initializable{

    private Parent root;
    private Scene scene;
    private Stage stage;


     @FXML
    private ChoiceBox<String> ChoiceBig;

    @FXML
    private ChoiceBox<String> ChoiceMedium;

    @FXML
    private ChoiceBox<String> ChoiceSmall;

    @FXML
    void ChoiceBig(ActionEvent event) {

    }
    @FXML
    void ChoiceMedium(ActionEvent event) {

    }
    @FXML
    void ChoiceSmall(ActionEvent event) {

    }

    @FXML
    private Button Logout;

    @FXML
    private TextField TFBig;

    @FXML
    private TextField TFMedium;

    @FXML
    private TextField TFSmall;

    @FXML
    private Button article;

    @FXML
    private Button catalog;

    @FXML
    private Button delivery;

    @FXML
    private Button salesData;

    @FXML
    private Button saveBig;

    @FXML
    private Button saveMedium;

    @FXML
    private Button saveSmall;

    @FXML
    private Button userData;

    @FXML
    private Button editBig;

    @FXML
    private Button editMedium;

    @FXML
    private Button editSmall;

    @FXML
    void logout(ActionEvent event) throws IOException{
      root  = FXMLLoader.load(getClass().getResource("/FXML/FXMLpembuka.fxml"));
      stage = (Stage)((Node)event.getSource()).getScene().getWindow();
      scene = new Scene(root);
      stage.setScene(scene);
      stage.show();
    }

    @FXML
    void article(ActionEvent event) throws IOException{
        root  = FXMLLoader.load(getClass().getResource("/FXML/editartikel.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    void delivery(ActionEvent event) throws IOException{
      root  = FXMLLoader.load(getClass().getResource("/FXML/FXMLdelivery.fxml"));
      stage = (Stage)((Node)event.getSource()).getScene().getWindow();
      scene = new Scene(root);
      stage.setScene(scene);
      stage.show();
    }

    @FXML
    void salesdata(ActionEvent event) throws IOException{
      root  = FXMLLoader.load(getClass().getResource("/FXML/FXMLsales.fxml"));
      stage = (Stage)((Node)event.getSource()).getScene().getWindow();
      scene = new Scene(root);
      stage.setScene(scene);
      stage.show();
    }

    @FXML
    void userdata(ActionEvent event) throws IOException{
      root  = FXMLLoader.load(getClass().getResource("/FXML/FXMLUserdata.fxml"));
      stage = (Stage)((Node)event.getSource()).getScene().getWindow();
      scene = new Scene(root);
      stage.setScene(scene);
      stage.show();
    }


    

    @Override
    public void initialize (URL url, ResourceBundle rb) {
        ChoiceBig.getItems().addAll("Aqua", "Fanta", "Teh Pucuk");
        ChoiceMedium.getItems().addAll("Aqua", "Fanta", "Teh Pucuk");
        ChoiceSmall.getItems().addAll("Aqua", "Fanta", "Teh Pucuk");

        ChoiceSmall.getSelectionModel().selectedIndexProperty().addListener((observable, oldValue, newValue) -> {
               if (newValue.intValue() >= 0) {
                    String selectedSmall = ChoiceSmall.getItems().get(newValue.intValue());
                    
               }
          });

        ChoiceBig.getSelectionModel().selectedIndexProperty().addListener((observable, oldValue, newValue) -> {
               if (newValue.intValue() >= 0) {
                    String selectedBig = ChoiceBig.getItems().get(newValue.intValue());
                    
              }
        });
        ChoiceSmall.getSelectionModel().selectedIndexProperty().addListener((observable, oldValue, newValue) -> {
               if (newValue.intValue() >= 0) {
                    String selectedMedium = ChoiceSmall.getItems().get(newValue.intValue());
                    
               }
          });
    }

     private boolean isEditBigClicked = false;

    @FXML
    void editBigClicked(ActionEvent event) {
        isEditBigClicked = true;
        TFBig.setEditable(true);
    }

    @FXML
    void saveBigClicked(ActionEvent event) {
        if (isEditBigClicked) {
            TFBig.setEditable(false);
            isEditBigClicked = false;
        }
    }

     private boolean isEditMediumClicked = false;

    @FXML
    void editMediumClicked(ActionEvent event) {
        isEditMediumClicked = true;
        TFMedium.setEditable(true);
    }

    @FXML
    void saveMediumClicked(ActionEvent event) {
        if (isEditMediumClicked) {
            TFMedium.setEditable(false);
            isEditMediumClicked = false;
        }
    }

     private boolean isEditSmallClicked = false;

    @FXML
    void editSmallClicked(ActionEvent event) {
        isEditSmallClicked = true;
        TFSmall.setEditable(true);
    }

    @FXML
    void saveSmallClicked(ActionEvent event) {
        if (isEditSmallClicked) {
            TFSmall.setEditable(false);
            isEditSmallClicked = false;
        }
    }

}
