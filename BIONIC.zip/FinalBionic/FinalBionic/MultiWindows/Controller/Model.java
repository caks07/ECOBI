package Controller;

import javafx.scene.chart.XYChart;

public class Model {

    private XYChart.Series<String, Integer> series;

    public Model() {
        series = new XYChart.Series<>();
        initData();
    }

    public XYChart.Series<String, Integer> getSeries() {
        return series;
    }

    private void initData() {
        series.getData().add(new XYChart.Data<>("January", 100));
        series.getData().add(new XYChart.Data<>("February", 50));
        series.getData().add(new XYChart.Data<>("March", 150));

    }

    public void addData(String name, int value) {
        series.getData().add(new XYChart.Data<>(name, value));
    }

    public void removeData(int index) {
        series.getData().remove(index);
    }

    public int getDataSize() {
        return series.getData().size();
    }

    public String getName(int index) {
        return series.getData().get(index).getXValue();
    }

    public int getValue(int index) {
        return series.getData().get(index).getYValue();
    }
}