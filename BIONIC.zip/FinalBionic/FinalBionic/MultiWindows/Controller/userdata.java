package Controller;

public class userdata {
    private String username;
    private String NOtelepon;
    private String alamat;
    private String password;

    public userdata(String username, String NOtelepon, String alamat, String password) {
        this.username = username;
        this.NOtelepon = NOtelepon;
        this.alamat = alamat;
        this.password = password;
    }

    public String getUsername() {
        return username;
    }

    public String getNOtelepon() {
        return NOtelepon;
    }

    public String getAlamat() {
        return alamat;
    }

    public String getPassword() {
        return password;
    }
}
