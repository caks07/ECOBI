/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Controller;
 
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

/**
 *
 * @author raja
 */

// deklarasi untuk objek di fxml

public class FXMLpilihanController implements Initializable {

    private Parent root;
    private Scene scene;
    private Stage stage;


    @FXML
    private Button Info1;

    @FXML
    private Button Info2;

    @FXML
    private Button Order;

    @FXML
    private Button Catalog;

    @FXML
    private Button Article;

    @FXML
    private Button Home;

    @FXML
    private Button Poin;

    @FXML
    private Button Logout;

    @FXML
    private Button profile;

    @FXML
    void Poin(ActionEvent event) throws IOException {
      root  = FXMLLoader.load(getClass().getResource("/FXML/FXMLpoinforuser.fxml"));
      stage = (Stage)((Node)event.getSource()).getScene().getWindow();
      scene = new Scene(root);
      stage.setScene(scene);
      stage.show();

    }

    @FXML
    void Catalog(ActionEvent event) throws IOException{
      root  = FXMLLoader.load(getClass().getResource("/FXML/katalog.fxml"));
      stage = (Stage)((Node)event.getSource()).getScene().getWindow();
      scene = new Scene(root);
      stage.setScene(scene);
      stage.show();
    }

    @FXML
    void Home(ActionEvent event) throws IOException {
      root  = FXMLLoader.load(getClass().getResource("/FXML/FXMLhome.fxml"));
      stage = (Stage)((Node)event.getSource()).getScene().getWindow();
      scene = new Scene(root);
      stage.setScene(scene);
      stage.show();
    }

    @FXML
    void Profile(ActionEvent event) throws IOException {
      root  = FXMLLoader.load(getClass().getResource("/FXML/FXMLprofile.fxml"));
      stage = (Stage)((Node)event.getSource()).getScene().getWindow();
      scene = new Scene(root);
      stage.setScene(scene);
      stage.show();
    }


    @FXML
    void LogOut(ActionEvent event) throws IOException  {
      root  = FXMLLoader.load(getClass().getResource("/FXML/FXMLpembuka.fxml"));
      stage = (Stage)((Node)event.getSource()).getScene().getWindow();
      scene = new Scene(root);
      stage.setScene(scene);
      stage.show();
    }

    @FXML
    void Info1(ActionEvent event) throws IOException  {
      root  = FXMLLoader.load(getClass().getResource("/FXML/FXMLartikel1.fxml"));
      stage = (Stage)((Node)event.getSource()).getScene().getWindow();
      scene = new Scene(root);
      stage.setScene(scene);
      stage.show();
    }

    @FXML
    void Order(ActionEvent event) throws IOException {
      root  = FXMLLoader.load(getClass().getResource("/FXML/order.fxml"));
      stage = (Stage)((Node)event.getSource()).getScene().getWindow();
      scene = new Scene(root);
      stage.setScene(scene);
      stage.show();
    }


    @FXML
    void Info2(ActionEvent event) throws IOException  {
      root  = FXMLLoader.load(getClass().getResource("/FXML/FXMLartikel2.fxml"));
      stage = (Stage)((Node)event.getSource()).getScene().getWindow();
      scene = new Scene(root);
      stage.setScene(scene);
      stage.show();
    }


    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
}
