package barchart;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.chart.BarChart;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.chart.XYChart;

public class FXMLDocumentController {

    private Model model;

    @FXML
    private Button Buttonhapus;

    @FXML
    private Button Buttontambah;

    @FXML
    private BarChart<String, Integer> city;

    @FXML
    private TextField indexField;

    @FXML
    private TextField kotaField;

    @FXML
    private TextField valueField;

    @FXML
    private Label label;

    @FXML
    private Button edit;

    @FXML
    private Button simpan;
    

    @FXML
    void handleButtonHapus(ActionEvent event) {
        int index = Integer.parseInt(indexField.getText());
        model.removeData(index);
        indexField.clear();
    }

    @FXML
    void handleButtonTambah(ActionEvent event) {
        String name = kotaField.getText();
        int value = Integer.parseInt(valueField.getText());
        model.addData(name, value);
        kotaField.clear();
        valueField.clear();
    }
    
    public void setModel(Model model) {
        this.model = model;
        city.getData().add(model.getSeries());
    }
}
